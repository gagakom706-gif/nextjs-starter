# ДоорсПро ИИ — Developer README

Корпоративный AI-вебсервис на Next.js для ДоорсПро: чат, нейропоиск, база знаний, загрузка файлов, история и готовность к Supabase/PostgreSQL.

## Что уже есть
- `app/page.tsx` — главный чат.
- `app/search/page.tsx` — нейропоиск.
- `app/knowledge/page.tsx` — база знаний и загрузка файлов.
- `app/history/page.tsx` — история чатов.
- `app/api/chat/route.ts` — streaming ответ от OpenAI.
- `app/api/search/route.ts` — hybrid search по демо-докам.
- `app/api/upload/route.ts` — приём файлов.
- `supabase_schema.sql` — схема БД для Supabase/Postgres.
- `PROJECT_STRUCTURE.md` — финальная структура проекта.

## Требования
- Node.js 20+
- npm 10+
- OpenAI API key
- Supabase project (для auth, storage, Postgres)

## Установка
```bash
cd nextjs-starter
npm install
```

## Переменные окружения
Создайте `.env.local` по примеру `.env.example`:

```bash
OPENAI_API_KEY=your_key_here
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=your_supabase_key
```

## Запуск
```bash
npm run dev
```

Откройте:
- `/` — чат
- `/search` — нейропоиск
- `/knowledge` — база знаний
- `/history` — история

## Как работает чат
Фронтенд отправляет сообщение в `/api/chat`, сервер вызывает OpenAI SDK и стримит ответ в браузер. Это уже правильный базовый паттерн для AI-chat приложений на Next.js App Router.

## Поиск по открытым источникам

Если нужна выдача из интернета, включите `OPENAI_WEB_SEARCH=true` в `.env.local`. В этом режиме чат будет использовать модель с web search и сможет отвечать по актуальным данным с источниками. Для продакшена рекомендуется добавлять модуль оркестрации, чтобы включать web search только для запросов, где это действительно нужно.

## Как работает нейропоиск
`/api/search` сейчас возвращает демо-результаты. На следующем этапе его нужно заменить на реальный RAG-пайплайн:
1. извлечь текст из загруженного файла;
2. разбить документ на чанки;
3. посчитать embeddings;
4. сохранить чанки в `document_chunks`;
5. искать по embeddings + keyword filter;
6. rerank top results;
7. собрать итоговый ответ LLM.

## Supabase schema
Выполните `supabase_schema.sql` в SQL Editor Supabase или как миграцию. Схема включает:
- `profiles`
- `workspaces`
- `workspace_members`
- `documents`
- `document_chunks`
- `chat_threads`
- `chat_messages`
- `search_queries`
- `search_results`
- `audit_logs`

## Рекомендуемый порядок внедрения
1. Подключить Supabase Auth.
2. Создать workspace и первого администратора.
3. Подключить storage bucket для файлов.
4. Сделать сохранение чатов в `chat_threads` и `chat_messages`.
5. Добавить реальную индексацию документов.
6. Заменить демо-поиск на RAG retrieval.
7. Включить RLS-проверки для всех рабочих таблиц.

## Следующие задачи для разработки
- Авторизация и logout.
- Загрузка PDF/DOCX/XLSX в Supabase Storage.
- Индексация документов в фоне.
- Сохранение истории и аудита.
- Подключение страниц `knowledge`, `search`, `history` к реальной БД.
- Админка для управления ролями и workspace.

## Структура
См. `PROJECT_STRUCTURE.md`.

## Примечания
- Не храните API keys в клиентском коде.
- Для RAG лучше разделять ingest pipeline и query pipeline.
- Для production включайте логирование запросов, ошибок и usage по токенам.
